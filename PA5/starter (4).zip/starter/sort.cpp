#include <iostream>
#include <queue>
using namespace std;

void bubbleSort(int *arr, int size){
    
}

void heapSort(int *arr, int size){

}

void mergeSort(int * arr, int start, int end) {
    
}

void quickSort(int *arr, int start, int end) {
    
}
