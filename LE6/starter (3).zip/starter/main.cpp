#include "lru.h"

int main() {
    return 0;
}