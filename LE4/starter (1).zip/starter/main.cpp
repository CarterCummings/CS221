#include "bst.h"
using namespace std;

#ifndef TEST
int main() {
    // You can write your own test cases here
    return 0;
}
#endif