#include <iostream>
#include <thread>
using namespace std;

void mergeSort(int * arr, int start, int end, int level) {
   
}